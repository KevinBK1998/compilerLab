//Code for creation of an expression tree and global symbol table
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "exptree.h"
int varcount=4096;  //initial SP=4095,push empty space for return value of main()
int fnid=-1;
gsnode *Gtop=NULL;
//Exit if Error
void Exit(){
  remove("x.xobj");
  exit(1);
}
//Symbol Table functions
int GetMem(){
  return varcount;
}
void addMain(){
  gsnode *temp=(gsnode*)malloc(sizeof(gsnode));
  temp->dtype=INTEGER;
  temp->name=(char*)malloc(strlen("main")*sizeof(char));
  strcpy(temp->name,"main");    
  temp->flabel=++fnid;
  temp->p=NULL;
  temp->n=NULL;
  Gtop=temp;
}
void GAllocate(tnode *id,int type,int size){
  gsnode *temp=(gsnode*)malloc(sizeof(gsnode));
  gsnode *check=getGSymbol(id->var);
  if(check){
    printf("Declaration Error:Identifier '%s' has already been declared\n",id);
    Exit();
  }
  if(id->ntype==FUNCTION){    
    temp->dtype=type;
    temp->name=(char*)malloc(strlen(id->var)*sizeof(char));
    strcpy(temp->name,id->var);    
    temp->flabel=++fnid;
    temp->size=id->dtype;
    temp->p=PDeclare(id->r);
    temp->n=NULL;
  }
  else{
    if(id->dtype)
      temp->flabel=id->dtype;
    else
      temp->flabel=-1;    
    temp->dtype=type;
    temp->name=(char*)malloc(strlen(id)*sizeof(char));
    strcpy(temp->name,id->var);
    temp->size=size;  
    temp->bind=++varcount;
    varcount+=size-1;
    temp->n=NULL;
  }
  gsnode *end=Gtop;
  if(Gtop==NULL){
    Gtop=temp;
    return;
  }
  while(end->n)
    end=end->n;
  end->n=temp;
    return;
}
void GDeclare(tnode *Dnode,tnode *Lnode){
  if(!Gtop)
    addMain();
  tnode *temp=Lnode;
  int type=Dnode->dtype,s;
  while(temp){
    s=1;
    if(temp->r)
      if(temp->ntype==IDENTIFIER)
        s*=temp->r->val;
      else
        s=0;
    GAllocate(temp,type,s);
    temp=temp->l;
  }
}
lsnode *LAllocate(lsnode *Ltop,tnode *id,int type){  
  lsnode *temp=(lsnode*)malloc(sizeof(lsnode));
  lsnode *check=getLSymbol(Ltop,id),*end;
  if(check){
    printf("Declaration Error:Identifier '%s' has already been declared\n",id);
    Exit();
  }
  temp->dtype=type;
  temp->ptr=id->dtype;
  temp->name=(char*)malloc(strlen(id->var)*sizeof(char));
  strcpy(temp->name,id->var);
  temp->n=NULL;
  end=Ltop;
  if(end==NULL){
    return temp;
  }
  while(end->n){
    end=end->n;}
  end->n=temp;
  return Ltop;
}
void LDeclare(lsnode **Ltop,tnode *Dnode,tnode *Lnode){
  tnode *temp=Lnode;
  int type=Dnode->dtype,s;
  while(temp){    
    *Ltop=LAllocate(*Ltop,temp,type);
    temp=temp->l;
  }
}
void addLocVar(lsnode **Ltop,tnode *line){  
  if(!line)
    return;  
  tnode *temp=line;
  while(temp){    
    LDeclare(Ltop,temp->r,temp->e);
    temp=temp->l;
  } 
}
lsnode *PDeclare(tnode *decl){
  tnode *id=decl;
  lsnode *end,*Ltop=NULL;
  while(id){
    lsnode *temp=(lsnode*)malloc(sizeof(lsnode));
    lsnode *check=getLSymbol(Ltop,id);
    if(check){
      printf("Declaration Error:Identifier '%s' has already been declared\n",id);
      Exit();
    }
    temp->name=(char*)malloc(strlen(id->var)*sizeof(char));
    strcpy(temp->name,id->var);
    temp->dtype=id->r->dtype;
    temp->ptr=id->dtype;
    temp->n=NULL;
    if(Ltop==NULL){
      Ltop=temp;
      id=id->l;
      continue;
    }
    end=Ltop;  
    while(end->n){
      end=end->n;      
      }
    end->n=temp;
    end=end->n;
    id=id->l;
  }
  return Ltop;  
}
lsnode *parAllocate(lsnode *p){
  lsnode *id=p;
  lsnode *end,*Ltop=NULL;
  while(id){
    lsnode *temp=(lsnode*)malloc(sizeof(lsnode));
    temp->name=(char*)malloc(strlen(id->name)*sizeof(char));
    strcpy(temp->name,id->name);
    temp->dtype=id->dtype;
    temp->ptr=id->ptr;
    temp->n=NULL;        
    if(Ltop==NULL){
      Ltop=temp;
      id=id->n;
      continue;
    }
    end=Ltop;  
    while(end->n)
      end=end->n;
    end->n=temp;
    id=id->n;
  }
  return Ltop;
}
gsnode *getGSymbol(char *s){
    gsnode *temp=Gtop;
    while(temp){
        if(strcmp(temp->name,s)==0)
            return temp;
        temp=temp->n;
    }
    return NULL;
}
lsnode *getLSymbol(lsnode *Ltop,char *s){
    lsnode *temp=Ltop;
    while(temp){
        if(strcmp(temp->name,s)==0)
          return temp;
        temp=temp->n;
    }
    return NULL;
}
char *getDtype(int type){
  char *s=(char*)malloc(3*sizeof(char));
  if(type==INTEGER)
    strcpy(s,"int");    
  else if(type==STRING)
    strcpy(s,"str");
  else
    strcpy(s,"N/A");
  return s;
}
void printGSymbols(){
    gsnode *temp=Gtop;
    printf("Global:");
    while(temp){
        printf("%s ",getDtype(temp->dtype));
        if(temp->flabel==PTR)
          printf("ptr_type ");
        else if(temp->flabel>-1){
          if(temp->size==PTR)
            printf("ptr_type ");
          printf("fn_type ");
        }
        printf("%s->",temp->name);
        temp=temp->n;
    }    
    printf("NULL\n");
}
void printLSymbols(char *s,lsnode *Ltop){
    lsnode *temp=Ltop;
    printf("Local of %s():",s);
    while(temp){
        printf("%s ",getDtype(temp->dtype));
        if(temp->ptr)
          printf("ptr_type ");
        printf("%s->",temp->name);
        temp=temp->n;
    }    
    printf("NULL\n");
}
void printPSymbols(char *s,lsnode *Ltop){
    lsnode *temp=Ltop;
    printf("Param of %s():",s);
    while(temp){
        printf("%s ",getDtype(temp->dtype));
        if(temp->ptr)
          printf("ptr_type ");
        printf("%s->",temp->name);
        temp=temp->n;
    }    
    printf("NULL\n");
}
void bindId(lsnode *Ltop,tnode **Id){
  tnode *id=*Id;
  lsnode *T=getLSymbol(Ltop,id->var);
  if(T){
    id->dtype=T->dtype;
    id->l=NULL;
    id->r=NULL;
    id->val=VARIABLE;
    if(T->ptr==PTR)
      id->val=POINTER;
    id->sym=(gsnode*)malloc(sizeof(gsnode));
    id->sym->size=LOCALREF;
    id->sym->p=T;
  }
  else{
    gsnode *t=getGSymbol(id->var);
    if(t){
      int rmax=t->size;
      id->dtype=t->dtype;
      tnode *size=id->l;
      id->r=NULL;
      id->val=VARIABLE;
      if(rmax>1){
        id->val=ARRAY1D;
      }
      if(t->flabel==PTR)
        id->val=POINTER;
      id->sym=t;
      if(id->val==ARRAY1D){
        if(size){
          finalize(Ltop,size);
          if(size->dtype!=INTEGER){
            printf("Index Error:Expected Integer Value\n");
            Exit();
          }    
          if(size->ntype==CONSTANT&&size->val>=rmax){
            printf("Index Error:Index value is more than size of array\n");
            Exit();
          }
        }
        else{
          printf("Index Error:Index of array '%s' has not been specified\n",id->var);
          Exit();
        }
      }
      else
        if(size){
          printf("Index Error:Identifier '%s' is not an array\n",id->var);
          Exit();
        }
    }
    else{
      printf("Declaration Error:Identifier '%s' has not been declared in this scope\n",id->var);
      Exit();
    }
  }
}
void bindVar(lsnode *Ltop,tnode *body){
  if(body->ntype==IDENTIFIER){
    bindId(Ltop,&body);
  }
  else if(body->ntype==FUNCTION){
    lsnode *temp1=body->sym->p;    
    tnode *temp2=body->l;
    while(temp1){
      bindVar(Ltop,temp2);
      checkTypeError(temp2);
      if(temp1->dtype!=temp2->dtype||(temp1->ptr==PTR&&temp2->val!=POINTER)||(temp1->ptr!=PTR&&temp2->val==POINTER)){
        printf("Type Mismatch Error:Argument %s has been defined as %s ",temp1->name,getDtype(temp1->dtype));
        if(temp1->ptr==PTR)
          printf("ptr_type ");
        printf("vs %s",getDtype(temp2->dtype));
        if(temp2->val==POINTER)
          printf("ptr_type ");
        printf("\n");
        Exit();
      }
      temp1=temp1->n;
      temp2=temp2->e;
    }
    return;
  }
  else
  {
    if(body->l)bindVar(Ltop,body->l);
    if(body->r)bindVar(Ltop,body->r);
    if(body->e)bindVar(Ltop,body->e);
  }  
}
void showVar(tnode *body){
  if(body->ntype==IDENTIFIER){
    if(body->sym->p)
      printf("%s %s, ",getDtype(body->dtype),body->sym->p->name);
    else if(body->sym)
      printf("%s %s, ",getDtype(body->dtype),body->sym->name);
  }
  else
  {
    if(body->l)showVar(body->l);
    if(body->r)showVar(body->r);
    if(body->e)showVar(body->e);
    printf("\n");
  }  
}

//Node creation and linking functions
int checkTypeError(tnode *root){
  int type1,type2,type,ntype1,ntype2;
  if(root)
  switch (root->ntype)
  { case CONSTANT:
      return root->dtype;
    case OPERATOR:
      type1=checkTypeError(root->l);type=root->dtype;ntype1=root->l->ntype;   
      if(strcmp(root->var,"**")&&strcmp(root->var,"&")&&strcmp(root->var,"!")){
        type2=checkTypeError(root->r);
        ntype2=root->r->ntype;        
      }
      else
      { switch(root->var[0]){
          case '!':
            if(ntype1==OPERATOR&&type1!=type){
              printf("Type Mismatch Error:Expected Boolean\n");
              Exit();
            }
            return root->dtype;
          case '&'://no need i guess
            type=INTEGER;
            if(ntype1!=IDENTIFIER||type1!=type){
              printf("Type Mismatch Error:Expected Integer\n");
              Exit();
            }
            root->dtype=type;
            root->val=POINTER;
            return type;
          case '*':
            type=INTEGER;
            if(root->l->val!=POINTER){
              printf("Dereference Error:Identifier '%s' is not a pointer\n",root->l->var);
              Exit();
            }
            root->dtype=type;
            root->val=VARIABLE;
            return root->dtype;
          default:
            printf("Unknown:Error\n");
            Exit();
            return root->dtype;
        }
      }
      if(root->var[0]=='L')type=BOOLEAN;
      if(type==BOOLEAN){
        if(root->var[0]=='L')
          if((ntype1==OPERATOR&&type1!=type)||(ntype2==OPERATOR&&type2!=type)){
            printf("Type Mismatch Error:Expected Boolean\n");
            Exit();
          }
          if((ntype1!=OPERATOR&&ntype2!=OPERATOR)&&type1!=type2){
            printf("Type Mismatch Error:Expected Boolean\n");
            Exit();
          }
      }
      else{
        if(type2!=type1){
          printf("Type Mismatch Error:Expected %s %s,%s %s\n",getDtype(type1),root->l->var,getDtype(type2),root->r->var);
          if(type1==STRING)
            printf("String\n");
          else
            printf("Integer\n");
          Exit();
        }
        if(strcmp(root->var,"=")==0)
          if(strcmp(root->l->var,"&")==0){
            printf("Assignment Error:Lvalue of any variable cannot be changed\n");
            Exit();
          }
        root->dtype=type1;
      }      
      return root->dtype;
    case IDENTIFIER:
      return root->dtype;
    case FUNCTION:
      return root->dtype;
    default:
      if(root->l)checkTypeError(root->l);
      if(root->r)checkTypeError(root->r);
      if(root->e)checkTypeError(root->e);
      return 0;
  }
}
int checkRetType(tnode *r,tnode *c){
  int i=0;
  if(c->ntype==JMP){
    if(c->val==RETURN_FN){
      tnode *ret=c->l;
      if(ret->dtype!=r->dtype)
        return 0;
      if(r->val==PTR){
        if(ret->ntype==OPERATOR)
          if(strcmp(ret->var,"&")==0&&ret->dtype!=r->dtype)
            return 0;
          else
            return 1;
        if(ret->ntype==IDENTIFIER)
          if(ret->val!=POINTER)
            return 0;
        if(ret->ntype==CONSTANT)
          return 0;
      }        
      return 1;
    }
  }
  else
  {   
      if(c->l)i+=checkRetType(r,c->l);
      if(c->r)i+=checkRetType(r,c->r);
      if(c->e)i+=checkRetType(r,c->e);
      return i;
  }  
}

tnode *makeFnDefNode(tnode *rtype,tnode *fname,tnode *pTop,tnode *lDecl,tnode *code){
  gsnode *fdecl=getGSymbol(fname->var);
  lsnode *Ltop=NULL;
  if(!fdecl){
    printf("Declaration Error:%s() has not been declared\n",fname->var);
    Exit();
  }
  if(fdecl->size!=fname->dtype){
    printf("Declaration Error:%s() has conflicting pointer return types DEF:%d and RET:%d\n",fname->var,fdecl->size,fname->dtype);
    Exit();
  }
  if((fdecl->dtype!=rtype->dtype)||(rtype->ntype==IDENTIFIER&&fdecl->size!=rtype->val)){
    printf("Declaration Error:%s() has conflicting return types DEF:%s and RETURN:%s\n",fname->var,getDtype(fdecl->dtype),getDtype(rtype->dtype));
    Exit();
  }
  if(pTop||fdecl->p){
    if(!pTop){
      printf("Definition Error:%s() expects some argument(s)\n",fname->var);
      Exit();
    }
    if(!fdecl->p){
      printf("Definition Error:Declaration of %s() contains no arguments\n",fname->var);
      Exit();
    }
    checkNameEquivalence(fdecl->p,PDeclare(pTop));
    Ltop=parAllocate(fdecl->p);
    fname->sym=fdecl; 
  }
  addLocVar(&Ltop,lDecl);
  fname->ntype=FUNCTION;  
  if(strcmp(fname->var,"main"))
    if(fdecl->size==POINTER)
      fname->val=FN_POINTER;  
    else
      fname->val=FN_SIMPLE;
  else
    fname->val=FN_DRVR;
  finalize(Ltop,code);
  rtype->val=fdecl->size;
  if(!checkRetType(rtype,code)){
    printf("Type Mismatch Error:%s() has return type %s\n",fname->var,getDtype(rtype->dtype));
    Exit();
  }
  fname->r=code;
  {
    tnode *L=(tnode*)malloc(sizeof(tnode));
    L->l=NULL;
    L->r=NULL;
    L->e=NULL;
    L->ntype=LST;
    L->sym=(gsnode*)malloc(sizeof(gsnode));
    L->sym->size=LOCALREF;
    L->sym->p=Ltop;
    fname->e=L;  
  }
  return fname;
  
  
}
void finalize(lsnode *Ltop,tnode *code){
  bindVar(Ltop,code);
  checkTypeError(code);
}
tnode *makeRetNode(tnode *retvalue){
  tnode *p=(tnode*)malloc(sizeof(tnode));
  p->val=RETURN_FN;
  p->ntype=JMP;
  p->l=retvalue;
  p->r=NULL;
  p->e=NULL;
  return p;
}
void checkNameEquivalence(lsnode *formal,lsnode *actual){
  lsnode *temp1=formal,*temp2=actual;
  while(temp1){
    if(!temp2){
      printf("Definition Error:Expecting more arguments in definition of function\n");
      Exit();
    }
    if(strcmp(temp1->name,temp2->name)){
      printf("Definition Error:Arguments in definition and declaration don't match\n");
      Exit();
    }
    if((temp1->dtype!=temp2->dtype)||(temp1->ptr!=temp2->ptr)){
      printf("Definition Error:Argument %s has conflicting types in definition and declaration\n",temp1->name);
      Exit();
    }
    temp1=temp1->n;
    temp2=temp2->n;
  }
  if(temp2){
    printf("Definition Error:Unexpected arguments in definition of function\n");
    Exit();
  }
}
tnode *makeOpNode(char *op,tnode *left,tnode *right,int type){
  tnode *p=(tnode*)malloc(sizeof(tnode));
  p->var=(char*)malloc(strlen(op)*sizeof(char));
  strcpy(p->var,op);
  p->ntype=OPERATOR;
  p->dtype=type;
  p->l=left;
  p->r=right;
  p->e=NULL;
  return p;
}
tnode *makeNumNode(int n){
  tnode *p=(tnode*)malloc(sizeof(tnode));
  p->dtype=INTEGER;
  p->ntype=CONSTANT;
  p->val=n;
  p->l=NULL;
  p->r=NULL;
  p->e=NULL;
  return p;
}
tnode *makeStrNode(char *s){
  tnode *p=(tnode*)malloc(sizeof(tnode));
  p->dtype=STRING;
  p->ntype=CONSTANT;
  p->var=(char*)malloc(strlen(s)*sizeof(char));
  strcpy(p->var,s);
  p->l=NULL;
  p->r=NULL;
  p->e=NULL;
  return p;
}
tnode *makeLocDecNode(tnode *type,tnode *list){
  tnode *p=(tnode*)malloc(sizeof(tnode));
  p->ntype=LDECLARE;
  p->r=type;
  p->e=list;
  p->l=NULL;
  return p;
}
tnode *makeUNode(tnode *left,tnode *right,int type){
  tnode *p=(tnode*)malloc(sizeof(tnode));
  p->ntype=JMP;
  p->dtype=type;
  p->l=left;
  p->r=right;
  p->e=NULL;
  return p;
}
tnode *makeIdNode(char *id){
  tnode *p=(tnode*)malloc(sizeof(tnode));
  p->ntype=IDENTIFIER;
  p->var=(char*)malloc(strlen(id)*sizeof(char));
  strcpy(p->var,id);
  p->l=NULL;
  p->r=NULL;
  p->e=NULL;
  return p;
}
tnode *makeGDeclLinkNode(tnode *prev,tnode *id,tnode *rows){
  id->l=NULL;
  id->r=rows;
  id->e=NULL;
  id->dtype=0;
  tnode *end=prev;
  if(end==NULL){
    return id;
  }
  while(end->l){
    end=end->l;
  }
  end->l=id;
  return prev;
}
tnode *makeParamLinkNode(tnode *prev,tnode *type,tnode *id){
  id->r=type;
  id->l=NULL;
  id->e=NULL;
  tnode *end=prev;
  if(end==NULL){
    return id;
  }  
  while(end->l){
    end=end->l;
  }
  end->l=id;
  end=prev;
  return prev;
}
tnode *makeFnDefLinkNode(tnode *prev,tnode *def){
  tnode *end=prev;
  if(end==NULL){
    return def;
  }  
  while(end->l){
    end=end->l;
  }
  end->l=def;
  return prev;
}
tnode *linkFnWithArg(lsnode *par,tnode *arg){
  lsnode *temp1=par,*Ltop;
  tnode *temp2=arg;
  while(temp1){
    if(!temp2){
      printf("Function Call Error:Expecting more arguments in function call\n");
      Exit();
    }
    temp1=temp1->n;
    temp2=temp2->e;
  }
  if(temp2){
    printf("Function Call Error:Unexpected arguments in function call\n");
    Exit();
  }
  return arg;
}
tnode *makeFnCallNode(tnode *fn,tnode *arg){
  gsnode *check=getGSymbol(fn->var);
  if(check){
    fn->ntype=FUNCTION;
    fn->dtype=check->dtype;
    fn->val=FN_CALL;
    fn->l=NULL;
    fn->r=NULL;
    fn->e=NULL;
    fn->sym=check;
    lsnode *par=check->p;
    fn->l=linkFnWithArg(par,arg);
  }
  else{
    printf("Declaration Error:Function %s() has not been declared\n",fn->var);
    Exit();
  }
  
  return fn;
}
void prntArg(tnode *start){
  tnode *end=start;
  while(end){
    if(end->ntype==IDENTIFIER)
      printf("%s %s,",getDtype(end->dtype),end->var);
    if(end->ntype==CONSTANT)
      if(end->dtype==STRING)
        printf("%s %s,",getDtype(end->dtype),end->var);
      else
        printf("%s %d,",getDtype(end->dtype),end->val);
    end=end->e;
  }
  printf("\b \n");
}
tnode *makeArgLinkNode(tnode *prev,tnode *arg){
  tnode *end=prev;
  if(end==NULL)
    return arg;
  while(end->e)
    end=end->e;
  end->e=arg;
  return prev;
}
tnode *linkLDeclLineNode(tnode *prev,tnode *line){
  tnode *end=prev;
  if(end==NULL){
    return line;
  }
  while(end->l){
    end=end->l;
  }
  end->l=line;
  return prev;
}
tnode *makeLDeclLinkNode(tnode *prev,tnode *id){
  id->l=NULL;
  id->e=NULL;
  tnode *end=prev;
  if(end==NULL){
    return id;
  }
  while(end->l){
    end=end->l;
  }
  end->l=id;
  return prev;
}
tnode *makePtrLinkNode(tnode *prev,tnode *id){
  id->l=NULL;
  id->r=NULL;
  id->e=NULL;
  id->dtype=PTR;
  tnode *end=prev;
  if(end==NULL){
    return id;
  }
  while(end->l){
    end=end->l;
  }
  end->l=id;
  return prev;
}
tnode *makeFnLinkNode(tnode *prev,tnode *id,tnode *param){
  id->l=NULL;
  id->r=param;
  id->ntype=FUNCTION;
  id->e=NULL;
  tnode *end=prev;
  if(end==NULL){
    return id;
  }
  while(end->l){
    end=end->l;
  }
  end->l=id;
  return prev;
}
tnode *makePtrNode(char *op,tnode *id){
  tnode *p=(tnode*)malloc(sizeof(tnode));
  p->var=(char*)malloc(strlen(op)*sizeof(char));
  strcpy(p->var,op);
  p->ntype=OPERATOR;
  p->dtype=INTEGER;
  p->l=id;
  p->r=NULL;
  p->e=NULL;
  return p;
}
tnode *makeIONode(int fcode,tnode *arg){
  tnode *p=(tnode*)malloc(sizeof(tnode));
  p->val=fcode;
  p->ntype=IO;
  p->l=arg;
  p->r=NULL;
  p->e=NULL;
  return p;
}
tnode *makeConNode(tnode *left,tnode *right){
  tnode *p=(tnode*)malloc(sizeof(tnode));
  p->ntype=CONNECTION;
  p->l=left;
  p->r=right;
  p->e=NULL;
  return p;
}
tnode *makeCtrlNode(tnode *left,tnode *right,tnode *Else,int type){
  if(((type==SIMPLE_IF||type==WHILE_LOOP)&&left->dtype!=BOOLEAN)||((type==REPEAT_LOOP||type==DO_LOOP)&&right->dtype!=BOOLEAN))
  {
    printf("Type Mismatch Error:Expected Boolean\n");
    Exit(); 
  }
  tnode *p=(tnode*)malloc(sizeof(tnode));
  p->ntype=CONTROL;
  p->dtype=type;
  p->l=left;
  p->r=right;
  p->e=Else;
  return p;
}
tnode *makeDtype(int type){
  tnode *p=(tnode*)malloc(sizeof(tnode));
  p->ntype=DATATYPE;
  p->dtype=type;
  p->l=NULL;
  p->r=NULL;
  p->e=NULL;
  return p;
}

tnode* linkIdNode(tnode *id,tnode *size){
  id->dtype=0;  
  id->l=size;
  id->r=NULL;
  id->val=VARIABLE;
  id->sym=NULL;
  return id;
}