//Control Type
#define SIMPLE_IF 0
#define IF_ELSE 1
#define WHILE_LOOP 2
#define BREAK_LOOP 3
#define CONT_LOOP 4
#define REPEAT_LOOP 5
#define DO_LOOP 6
#define RETURN_FN 7
#define LOCALREF 8000 
//Function type
#define FN_WRITE 0
#define FN_READ 1
#define FN_SIMPLE 2
#define FN_POINTER 3
#define FN_DRVR 4
#define FN_CALL 5
//Data type
#define NO_TYPE 0
#define INTEGER 1
#define BOOLEAN 2 
#define STRING 3
#define PTR 4000
//Identifier Type
#define VARIABLE 0
#define POINTER 1
#define ARRAY1D 2
//Node Type
#define CONSTANT 0
#define OPERATOR 1
#define IO 2
#define CONNECTION 3
#define CONTROL 4
#define JMP 5
#define DATATYPE 6
#define IDENTIFIER 7
#define FUNCTION 8
#define LDECLARE 9
#define LST 10
typedef struct lsnode{
    char *name;
    int dtype;
    int bind;
    int ptr;
    struct lsnode *n;
}lsnode;
typedef struct gsnode{
    char *name;
    int dtype;
    int flabel;         //pointer or function
    int size;
    int bind;
    struct lsnode *p;
    struct gsnode *n;
}gsnode;
typedef struct tnode{
    int val;
    int dtype;
    char *var;
    int ntype;
    gsnode *sym;
    struct tnode *l,*r,*e;
}tnode;
void GAllocate(tnode*,int,int);
void GDeclare(tnode *,tnode *);
void LDeclare(lsnode **,tnode *,tnode *);
lsnode *PDeclare(tnode *);
lsnode *getLSymbol(lsnode*,char *);
gsnode *getGSymbol(char *);
char *getDtype(int);
//tnode* linkIdNode(tnode *,tnode *);
void printGSymbols();
tnode *makeOpNode(char*,tnode*,tnode*,int);
tnode *makeNumNode(int);
tnode *makeIdNode(char*);
tnode *makeUNode(tnode*,tnode*,int);
tnode *makeIONode(int,tnode*);
tnode *makeConNode(tnode*,tnode*);
tnode *CtrlNode(tnode*,tnode*,tnode*,int);
tnode *makePtrNode(char*,tnode *);
tnode *makeDeclLinkNode(tnode *,tnode *,tnode *);