/*Code for converting an expression tree to assembly code
  1.Output is a intermediate file called 'x.xobj'
  2.Intermediate file includes labels of L<unique-id>
  3.Pushes registers in use to stack before library fn and pops them back after execution of fn
*/
#include<stdio.h>
#include<string.h>
#include "assembler.h"
#define FOUT "x.xobj" 
//#include "exptree.c"  //comment before use
int regcount=-1,lblct=-1,fnct=-1;
FILE *out;
int getFreshReg(){
    if(regcount<RMAX-1)
      return ++regcount;
    printf("Error:Out Of Free Registers\n");
    return -1;
}
int saveRegToStack(){
  int i=0,r=regcount;
  while(i<=r){
    fprintf(out,"PUSH R%d\n",i);
    freeReg();
    i++;
  }
  return r;
}
int loadRegFromStack(int regmax){
  int i=regmax;
  while(i>=0){
    fprintf(out,"POP R%d\n",i);
    i--;
  }
  regcount=regmax;
  return regcount;
}
int freeReg(){
  if(regcount>-1){
    regcount--;
    return 0;
  }
  return -1;
}
int getLabel(){
  return ++lblct;
}
int getRVal(tnode *varNode){
  int rega;
  rega=getLVal(varNode);
  fprintf(out,"MOV R%d,[R%d]\n",rega,rega);
  return rega;
}
int getLVal(tnode *varNode){  
  int rega,regb,regt;
  tnode *expR=varNode->l;
  gsnode *id=varNode->sym;
  if(id->size!=LOCALREF){
    switch(varNode->val){
        case VARIABLE:
        case POINTER:
            rega=getFreshReg();
            fprintf(out,"MOV R%d,%d\n",rega,id->bind);
            return rega;
        case ARRAY1D:
            rega=getFreshReg();
            fprintf(out,"MOV R%d,%d\n",rega,id->bind);
            regb=expCodeGen(expR);
            fprintf(out,"ADD R%d,R%d\n",rega,regb);
            freeReg();
            return rega;        
    }
  }
  else
  {
    rega=getFreshReg();
    regb=getFreshReg();
    int t=id->p->bind;
    if(t>0){
      fprintf(out,"MOV R%d,BP\n",rega);
      fprintf(out,"MOV R%d,%d\n",regb,t);      
      fprintf(out,"ADD R%d,R%d\n",rega,regb);
      freeReg();
      return rega;
    }
    else if(t<-2){
      fprintf(out,"MOV R%d,BP\n",rega);
      fprintf(out,"MOV R%d,%d\n",regb,-t);
      fprintf(out,"SUB R%d,R%d\n",rega,regb);
      freeReg();
      return rega;
    }
  }  
}
int codeInit(char *fnme){
    out=fopen(fnme,"w");
    fprintf(out,"%d\n%d\n%d\n%d\n",0,2056,0,0);
    fprintf(out,"%d\n%d\n%d\n%d\n",0,0,0,0);
    fprintf(out,"MOV SP,%d\nCALL MAIN\n",GetMem());
    freeReg();
    return 1;
}
int codeGen(tnode *root,tnode *Ltop,int lc,int lb,int pos){
  switch(root->ntype){
    case OPERATOR:
        //printf("OP ");
        return expCodeGen(root);
    case IO:
        switch(root->val){
            case FN_READ:
                //printf("Read ");
                return codeRead(root->l);
            case FN_WRITE:
                //printf("Write ");
                return codeWrite(root->l);
        }
    case FUNCTION:
        switch(root->val){
            case FN_SIMPLE:
                return codeFnDef(root);
            case FN_POINTER:
                return codeFnDef(root);
            case FN_DRVR:
                return codeFnDef(root);
        } 
    case CONNECTION:
      if(root->l)
        codeGen(root->l,Ltop,lc,lb,pos);
      if(root->r)
        codeGen(root->r,Ltop,lc,lb,pos);     
      return 0;
    case CONTROL:
      //printf("Control ");
      ctrlCodeGen(root,Ltop,lc,lb,pos);
      return 0;
    case JMP:
      //printf("Jump ");
      if(root->val==RETURN_FN)
      return codeRet(root->l);
      else
      return brkFlowGen(root,Ltop,lc,lb,pos);
    default:
        printf("Error:Something else %d ",root->ntype);
  }
}
int codeAsmble(tnode *code){
    codeInit(FOUT);
    if(code)
      codeGen(code,NULL,-1,-1,OUT_LOOP);
    free(code);
    fclose(out);
    return 1;
}
int codeRet(tnode *retv){
  int rega,regb;
  rega=getFreshReg();
  regb=getFreshReg();
  fprintf(out,"MOV R%d,BP\n",rega);
  fprintf(out,"MOV R%d,%d\n",regb,2);  
  fprintf(out,"SUB R%d,R%d\n",rega,regb);
  freeReg();
  regb=expCodeGen(retv);
  fprintf(out,"MOV [R%d],R%d\n",rega,regb);
  freeReg();
  freeReg();
  return 0;
}
int codeRead(tnode *t){
  int SAVE=saveRegToStack();
  int reg=getLVal(t);
  int temp=getFreshReg();
  fprintf(out,"MOV R%d,7\t;Read Begins\nPUSH R%d\n",temp,temp);
  fprintf(out,"MOV R%d,R%d\t;Value stored here\nPUSH R%d\n",temp,reg,temp);
  fprintf(out,"CALL 0\n");
  fprintf(out,"POP R%d\nPOP R%d\t;Read Ends\n",temp,temp);
  freeReg();
  freeReg();
  loadRegFromStack(SAVE);
  return 0;
}
int codeWrite(tnode *t){
  int SAVE=saveRegToStack();
  int reg=expCodeGen(t);
  int temp=getFreshReg();
  fprintf(out,"MOV R%d,5\t;Write Begins\nPUSH R%d\n",temp,temp);
  fprintf(out,"MOV R%d,R%d\t;Data taken from here\nPUSH R%d\n",temp,reg,temp);
  fprintf(out,"CALL 0\n");
  fprintf(out,"POP R%d\nPOP R%d\t;Write Ends\n",temp,temp);
  freeReg();
  freeReg();
  loadRegFromStack(SAVE);
  return 0;
}
int codeExit(){
  int SAVE=saveRegToStack();
  int temp=getFreshReg();
  fprintf(out,"MOV R%d,10\t;Exit Begins\n",temp);
  fprintf(out,"PUSH R%d\nPUSH R%d\n",temp,temp);
  fprintf(out,"CALL 0\n");
  fprintf(out,"POP R%d\nPOP R%d\t;Exit Ends\n",temp,temp);
  freeReg();
  loadRegFromStack(SAVE);
  return 1;
}
int codeFnDef(tnode *fn){
    int fnid=0,reg;
    if(!fn)
      return -1;
    if(strcmp(fn->var,"main")){
        fnid=getFnLabel(fn);
        //printf("FnDef%d\n",fnid);
        fprintf(out,"F%d:",fnid);
        reg=getFreshReg();
        fprintf(out,"MOV R%d,BP\t;fn%d\nPUSH R%d\n",reg,fnid,reg);
        fprintf(out,"MOV BP,SP\n");
        freeReg();        
        Lalloc(fn);
        codeGen(fn->r,fn->e,-1,-1,OUT_LOOP);
        DeAlloc(fn);
        fprintf(out,"POP BP\n");
        fprintf(out,"RET\n");
        //printf("\n");
        codeFnDef(fn->l);
    }
    else{
        //printf("Main\n");
        fprintf(out,"MAIN:");
        reg=getFreshReg();
        fprintf(out,"MOV R%d,BP\t;main\nPUSH R%d\n",reg,reg);
        fprintf(out,"MOV BP,SP\n");
        freeReg();
        Lalloc(fn);
        codeGen(fn->r,fn->e,-1,-1,OUT_LOOP);
        DeAlloc(fn);
        fprintf(out,"POP BP\n");
        codeExit();
        fprintf(out,"RET\n");
        //printf("\n");
        codeFnDef(fn->l);      
    }
    return fnid;
}
void Lalloc(tnode *fn){
  tnode *L=fn->e;  
  gsnode *Lref,*P=fn->sym;
  if(L)
    Lref=L->sym;
  lsnode *Ltop,*temp1,*temp2,*Ptop;
  if(Lref){
    Ltop=Lref->p;
    if(P)
      Ptop=P->p;
  }
  temp1=Ltop;
  temp2=Ptop;
  if(fn->val==FN_DRVR)
    temp2=NULL;
  else
    temp2=Ptop;  
  int n=-3,i=0;
  while(temp2){
    temp1->bind=n;
    //printf("Arg:%s Bind:%d ",temp2->name,temp1->bind);
    temp1=temp1->n;
    temp2=temp2->n;
    n--;i++;
  }
  n=1;i=0;
  while(temp1){
    temp1->bind=n;
    fprintf(out,"PUSH R%d\n",getFreshReg());
    freeReg();
    //printf("Var:%s Bind:%d ",temp1->name,temp1->bind);
    temp1=temp1->n;
    n++;i++;
  }
}
void DeAlloc(tnode *fn){
  tnode *L=fn->e;  
  gsnode *Lref,*P=fn->sym;
  if(L)
    Lref=L->sym;
  lsnode *Ltop,*temp1,*temp2,*Ptop;
  if(Lref){
    Ltop=Lref->p;
    if(P)
      Ptop=P->p;
  }
  temp1=Ltop;  
  if(fn->val==FN_DRVR)
    temp2=NULL;
  else
    temp2=Ptop;  
  while(temp2){
    temp1=temp1->n;
    temp2=temp2->n;
  }
  while(temp1){
    fprintf(out,"POP R%d\n",getFreshReg());
    freeReg();
    temp1=temp1->n;
  }
}
void pushArg(tnode *arg){
  int reg;
  if(arg){
    pushArg(arg->e);
    reg=expCodeGen(arg);
    fprintf(out,"PUSH R%d\n",reg);
    freeReg();
  }
}
int codeFnCall(tnode *fn){
    int SAVE=saveRegToStack(),reg,ret;
    tnode *arg=fn->l;
    //printf("FnCall%d ",getFnLabel(fn));
    pushArg(arg);
    reg=getFreshReg();
    fprintf(out,"PUSH R%d\n",reg);
    freeReg();
    fprintf(out,"CALL F%d\n",getFnLabel(fn));   //return value in highest reg
    ret=getFreshReg();
    fprintf(out,"POP R%d\n",reg);
    arg=fn->l;
    while(arg){
      reg=getFreshReg();
      fprintf(out,"POP R%d\n",reg);
      arg=arg->e;
      freeReg();
    }
    reg=SAVE+1;
    if(reg!=ret){
      fprintf(out,"MOV R%d,R%d\n",reg,ret);
      freeReg();
    }
    loadRegFromStack(SAVE);
    getFreshReg();
    return reg;
}
int getFnLabel(tnode *fn){
    gsnode *check=getGSymbol(fn->var);
    return check->flabel;
}

int expCodeGen(tnode *exp){
  int rega,regb,var;
  switch(exp->ntype){
    case CONSTANT:
      switch(exp->dtype){
        case INTEGER:
          rega=getFreshReg();
          //printf("K ");
          fprintf(out,"MOV R%d,%d\n",rega,exp->val);
          return rega;
        case STRING:
          rega=getFreshReg();
          fprintf(out,"MOV R%d,%s\n",rega,exp->var);
          return rega;
      }
    case OPERATOR:
      if(strlen(exp->var)==1){
        switch(exp->var[0]){
          case '+':
            rega=expCodeGen(exp->l);
            regb=expCodeGen(exp->r);
            fprintf(out,"ADD R%d,R%d\n",rega,regb);
            freeReg();
            return rega;
          case '*':
            rega=expCodeGen(exp->l);
            regb=expCodeGen(exp->r);
            fprintf(out,"MUL R%d,R%d\n",rega,regb);
            freeReg();
            return rega;
          case '-':
            rega=expCodeGen(exp->l);
            regb=expCodeGen(exp->r);
            fprintf(out,"SUB R%d,R%d\n",rega,regb);
            freeReg();
            return rega;
          case '/':
            rega=expCodeGen(exp->l);
            regb=expCodeGen(exp->r);
            fprintf(out,"DIV R%d,R%d\n",rega,regb);
            freeReg();
            return rega;
          case '<':
            rega=expCodeGen(exp->l);
            regb=expCodeGen(exp->r);
            fprintf(out,"LT R%d,R%d\n",rega,regb);
            freeReg();
            return rega;
          case '>':
            rega=expCodeGen(exp->l);
            regb=expCodeGen(exp->r);
            fprintf(out,"GT R%d,R%d\n",rega,regb);
            freeReg();
            return rega;
          case '=':
            if(strcmp(exp->l->var,"**")==0)
              rega=getRVal(exp->l->l);
            else
              rega=getLVal(exp->l);
            regb=expCodeGen(exp->r);
            fprintf(out,"MOV [R%d],R%d\n",rega,regb);
            freeReg();
            freeReg();
            return rega;
          case '!':
            rega=expCodeGen(exp->l);
            regb=getFreshReg();
            fprintf(out,"MOV R%d,%d\t;Code for\n",regb,0);
            fprintf(out,"EQ R%d,R%d\t;NOT\n",rega,regb);
            freeReg();
            return rega;
          case '&':
            return getLVal(exp->l);
        }
      }
      else{
        switch(exp->var[1]){
          case '<':
            rega=expCodeGen(exp->l);
            regb=expCodeGen(exp->r);
            fprintf(out,"LE R%d,R%d\n",rega,regb);
            freeReg();
            return rega;
          case '>':
            rega=expCodeGen(exp->l);
            regb=expCodeGen(exp->r);
            fprintf(out,"GE R%d,R%d\n",rega,regb);
            freeReg();
            return rega;
          case '%':
            rega=expCodeGen(exp->l);
            regb=expCodeGen(exp->r);
            fprintf(out,"MOD R%d,R%d\n",rega,regb);
            freeReg();
            return rega;
          case '=':
            rega=expCodeGen(exp->l);
            regb=expCodeGen(exp->r);
            fprintf(out,"EQ R%d,R%d\n",rega,regb);
            freeReg();
            return rega;
          case '!':
            rega=expCodeGen(exp->l);
            regb=expCodeGen(exp->r);
            fprintf(out,"NE R%d,R%d\n",rega,regb);
            freeReg();
            return rega;
          case '|':
            rega=expCodeGen(exp->l);
            regb=expCodeGen(exp->r);
            fprintf(out,"ADD R%d,R%d\n",rega,regb);
            freeReg();
            return rega;
          case '&':
            rega=expCodeGen(exp->l);
            regb=expCodeGen(exp->r);
            fprintf(out,"MUL R%d,R%d\n",rega,regb);
            freeReg();
            return rega;
          case '*':
            rega=getRVal(exp->l);
            fprintf(out,"MOV R%d,[R%d]\n",rega,rega);
            return rega;
        }
      }
    case IDENTIFIER:
      //printf("ID ");
      return getRVal(exp);
    case FUNCTION:
      return codeFnCall(exp);
  }
}
int brkFlowGen(tnode *root,tnode *Ltop,int lc,int lb,int pos){
  int l1,reg;
  if(pos==OUT_LOOP){
    if(root->l!=NULL)
      codeGen(root->l,Ltop,lc,lb,pos);
    if(root->r!=NULL)
      codeGen(root->r,Ltop,lc,lb,pos);
    return 0;
  }
  if(root->dtype==BREAK_LOOP){
    if(root->l!=NULL)
      codeGen(root->l,Ltop,lc,lb,pos);
    fprintf(out,"JMP L%d\n",lb);
    if(root->r!=NULL)
      codeGen(root->r,Ltop,lc,lb,pos);
  }
  else{
    if(root->l!=NULL)
      codeGen(root->l,Ltop,lc,lb,pos);
      fprintf(out,"JMP L%d\n",lc);
      if(root->r!=NULL)
        codeGen(root->r,Ltop,lc,lb,pos);
  }
}
int ctrlCodeGen(tnode *exp,tnode *Ltop,int lc,int lb,int pos){
  int l1,l2,reg;
    switch(exp->dtype){
        case SIMPLE_IF:
          l1=getLabel();
          reg=expCodeGen(exp->l);
          fprintf(out,"JZ R%d,L%d\n",reg,l1);
          freeReg();
          codeGen(exp->r,Ltop,lc,lb,pos);
          fprintf(out,"L%d:",l1);
          return 1;
        case IF_ELSE:
          l1=getLabel();
          l2=getLabel();
          reg=expCodeGen(exp->l);
          fprintf(out,"JZ R%d,L%d\n",reg,l1);
          freeReg();
          codeGen(exp->r,Ltop,lc,lb,pos);
          fprintf(out,"JMP L%d\nL%d:",l2,l1);
          codeGen(exp->e,Ltop,lc,lb,pos);
          fprintf(out,"L%d:",l2);         
          return 1;
        case WHILE_LOOP:
          l1=getLabel();
          l2=getLabel();
          fprintf(out,"L%d:",l1);
          reg=expCodeGen(exp->l);
          fprintf(out,"JZ R%d,L%d\n",reg,l2);
          freeReg();
          codeGen(exp->r,Ltop,l1,l2,IN_LOOP);
          fprintf(out,"JMP L%d\nL%d:",l1,l2);          
          return 1;
        case DO_LOOP:
          l1=getLabel();
          l2=getLabel();
          fprintf(out,"L%d:",l1);
          codeGen(exp->l,Ltop,l1,l2,IN_LOOP);
          reg=expCodeGen(exp->r);
          fprintf(out,"JNZ R%d,L%d\nL%d:",reg,l1,l2);
          freeReg();
          return 1;
        case REPEAT_LOOP:
          l1=getLabel();
          l2=getLabel();
          fprintf(out,"L%d:",l1);
          codeGen(exp->l,Ltop,l1,l2,IN_LOOP);
          reg=expCodeGen(exp->r);
          fprintf(out,"JZ R%d,L%d\nL%d:",reg,l1,l2);
          freeReg();
          return 1;
    }
}