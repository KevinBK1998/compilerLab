#define RMAX 20
#define OUT_LOOP 0
#define IN_LOOP 1
int getFreshReg();
int saveRegToStack();
int loadRegFromStack(int);
int freeReg();
int codeInit(char*);
int codeGen(tnode*,tnode*,int,int,int);
int loopCodeGen(tnode*,int,int);
int codeRead(tnode*);
int codeWrite(tnode*);
int codeExit();
int codeAsmble(tnode*);
int expCodeGen(tnode*);
int getVar(tnode*);
int brkFlowGen(tnode*,tnode*,int,int,int);