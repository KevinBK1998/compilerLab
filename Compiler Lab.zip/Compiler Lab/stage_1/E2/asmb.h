int getReg();
void freeReg();
int codeGen(tnode*);
int codeInit(char*);
int codeAsmble(tnode*);
int codeRead(int);
int codeWrite(int);
int codeExit();